package com.example.myapplication;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.Menu;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.ui.kittencounter.KittenCounterFragment;
import com.example.myapplication.ui.kitten.KittenFragment;
import com.example.myapplication.ui.pystota.PystotaFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarMain.toolbar);

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.kittenlove, R.id.countkitten, R.id.pysto)
                .setOpenableLayout(drawer)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if(id == R.id.kittenlove){
                getSupportActionBar().setTitle("Kitten");
                setFragment(new KittenFragment());
            } else if(id == R.id.countkitten){
                getSupportActionBar().setTitle("CountKitten");
                setFragment(new KittenCounterFragment());
            } else if(id == R.id.pysto){
                getSupportActionBar().setTitle("Pystota");
                setFragment(new PystotaFragment());
            }
            drawer.closeDrawer(GravityCompat.START);
            return true;
        });

        bottomNav = findViewById(R.id.bottomNavigation);

        // Установка listener'а для обработки выбора пункта в BottomNavigationView
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.kittenlove) {
                setFragment(new KittenFragment());
                getSupportActionBar().setTitle("Kitten");
                navigationView.setCheckedItem(R.id.kittenlove);
                return true;
            } else if (id == R.id.countkitten) {
                setFragment(new KittenCounterFragment());
                getSupportActionBar().setTitle("CountKitten");
                navigationView.setCheckedItem(R.id.countkitten);
                return true;
            } else if (id == R.id.pysto) {
                setFragment(new PystotaFragment());
                getSupportActionBar().setTitle("Pystota");
                navigationView.setCheckedItem(R.id.pysto);
                return true;
            }
            return false;
        });


        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.kittenlove); // Устанавливаем KittenFragment при первом запуске
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        NavigationView navigationView = binding.navView;

        if (id == R.id.setting_item) {
            Toast.makeText(this, "Настройки", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.first_item) {
            bottomNav.setSelectedItemId(R.id.kittenlove);
        } else if (id == R.id.second_item) {
            bottomNav.setSelectedItemId(R.id.countkitten);
        } else if (id == R.id.third_item) {
            bottomNav.setSelectedItemId(R.id.pysto);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void setFragment(Fragment fragment){
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.nav_host_fragment_content_main, fragment, null)
                .commit();
    }
}
