package com.example.myapplication.ui.kitten;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;

public class KittenFragment extends Fragment {

    private TextView kittens;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_kitten, container, false);
        kittens = (TextView)root.findViewById(R.id.change_color);
        registerForContextMenu(kittens);
        return root;
    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = requireActivity().getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        kittens = getView().findViewById(R.id.change_color);
        if(id == R.id.verylove){
            kittens.setText("Правильно!!!");
            kittens.setTextColor(getResources().getColor(R.color.pink));
            return true;
        }
        else if (id == R.id.love){
            kittens.setText("Ну неплохо...");
            kittens.setTextColor(getResources().getColor(R.color.green));
            return true;
        }
        else if(id == R.id.dontlove){
            kittens.setText("Фууууу ты лох");
            kittens.setTextColor(getResources().getColor(R.color.black));
            return true;
        }
        return super.onContextItemSelected(item);
    }
}