package com.example.myapplication.ui.kittencounter;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;

public class KittenCounterFragment extends Fragment {

    private Button countkitten;
    private TextView count;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_kittencounter, container, false);
        countkitten = root.findViewById(R.id.kittenscounter);
        count = root.findViewById(R.id.number);
        countkitten.setOnClickListener(v -> showPopup(countkitten));
        return root;
    }

    @SuppressLint("RestrictedApi")
    private void showPopup(View v){
        @SuppressLint("RestrictedApi") MenuBuilder menuBuilder = new MenuBuilder(getActivity());
        MenuInflater inflater = new MenuInflater(getActivity());
        inflater.inflate(R.menu.contex_menu_counter, menuBuilder);
        @SuppressLint("RestrictedApi") MenuPopupHelper optionsMenu = new MenuPopupHelper(getActivity(), menuBuilder, v);
        optionsMenu.setForceShowIcon(true);
        menuBuilder.setCallback(new MenuBuilder.Callback() {
            @SuppressLint("RestrictedApi")
            @Override
            public boolean onMenuItemSelected(@NonNull MenuBuilder menu, @NonNull MenuItem item) {
                int id = item.getItemId();
                int currentCount = 0;
                if (!count.getText().toString().isEmpty()) {
                    currentCount = Integer.parseInt(count.getText().toString().replaceAll("\\D", ""));
                }
                if (id == R.id.pluskitten) {
                    currentCount++;
                    String countText = "";
                    if (currentCount > 4 || currentCount == 0) {
                        countText = currentCount + " котиков";
                    } else if (currentCount == 1) {
                        countText = currentCount + " котик";
                    } else {
                        countText = currentCount + " котика";
                    }
                    count.setText(countText);
                    return true;
                } else if (id == R.id.minuskitten) {
                    if (currentCount > 0) {
                        currentCount--;
                        String countText = "";
                        if (currentCount > 4 || currentCount == 0) {
                            countText = currentCount + " котиков";
                        } else if (currentCount == 1) {
                            countText = currentCount + " котик";
                        } else {
                            countText = currentCount + " котика";
                        }
                        count.setText(countText);
                    } else {
                        Toast.makeText(getActivity(), "Котиков не может быть меньше 0, олух!!!!", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return true;
            }

            @Override
            public void onMenuModeChange(@NonNull MenuBuilder menu) {

            }
        });
        optionsMenu.show();
    }
}